@replaceMethod(MeleeThrowReloadEvents)
  public func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    if MeleeTransition.MeleeAttackPressed(scriptInterface) {
      if !this.m_isSwitchingWeapon && this.GetInStateTime() > TweakDBInterface.GetFloat(t"Items.MeleeWeapon.weaponSwapOnAttackDelay", 0.40) {
      };
    };
  }
