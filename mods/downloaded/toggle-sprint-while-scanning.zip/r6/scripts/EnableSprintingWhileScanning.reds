module EnhancedScanner.ToggleWalking

@wrapMethod(AimWalkDecisions)
  protected const func EnterCondition(const stateContext: ref<StateContext>, const scriptInterface: ref<StateGameScriptInterface>) -> Bool {
    if this.m_inFocusMode {
      return false;
    } else {
      return wrappedMethod(stateContext, scriptInterface);
    };
  }

@wrapMethod(SprintEvents)
  public func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.m_previousStimTimeStamp = -1.00;
    this.m_isInSecondSprint = false;
    this.m_sprintAnimBlocked = false;
    super.OnEnter(stateContext, scriptInterface);
    this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.Locomotion, 2);
    this.ProcessPermanentBoolParameterToggle(n"WalkToggled", false, stateContext);
    this.SetupSprintInputLock(stateContext, scriptInterface);
    stateContext.SetConditionBoolParameter(n"blockEnteringSlide", false, true);
    stateContext.SetConditionBoolParameter(n"CrouchToggled", false, true);
    stateContext.SetTemporaryBoolParameter(n"CancelGrenadeAction", true, true);
//    this.ForceDisableVisionModeWithInput(stateContext, scriptInterface);
    this.StartEffect(scriptInterface, n"locomotion_sprint");
    if !scriptInterface.HasStatFlag(gamedataStatType.CanWeaponReloadWhileSprinting) && scriptInterface.localBlackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Weapon) == 2 {
      stateContext.SetTemporaryBoolParameter(n"TryInterruptReload", true, true);
    };
    this.SetDetailedState(scriptInterface, gamePSMDetailedLocomotionStates.Sprint);
  }

@wrapMethod(PlayerVisionModeController)
  private final func ActivateVisionMode() -> Void {
    GameInstance.GetVisionModeSystem(this.m_owner.GetGame()).GetScanningController().EnterMode(this.m_owner, gameScanningMode.Heavy);
    if !this.m_owner.GetHudManager().IsQuickHackPanelOpened() {
      GameInstance.GetTargetingSystem(this.m_owner.GetGame()).AimSnap(this.m_owner);
    };
//    this.SendPSMBoolParameter(n"InterruptSprint", true, gamestateMachineParameterAspect.Temporary);
//    this.SendPSMBoolParameter(n"OnInterruptSprintFail_BlockSprintStartOnce", true, gamestateMachineParameterAspect.Conditional);
    this.ApplyFocusModeLocomotionRestriction();
    GameInstance.GetVisionModeSystem(this.m_owner.GetGame()).EnterMode(this.m_owner, gameVisionModeType.Focus);
    this.SetBlackboardIntVariable(GetAllBlackboardDefs().PlayerStateMachine, GetAllBlackboardDefs().PlayerStateMachine.Vision, 1);
    this.SetFocusModeAnimFeature(true);
    this.SetupLockToggleInput();
    this.SetupLockHoldInput();
    GameInstance.GetAudioSystem(this.m_owner.GetGame()).NotifyGameTone(n"Scanning");
    this.m_otherVars.m_enabledByToggle = this.m_inputActiveFlags.m_buttonToggle;
  }