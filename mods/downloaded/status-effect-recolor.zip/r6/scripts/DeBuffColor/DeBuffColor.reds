// DeBuffColorFull - Scream81
module DeBuffColor

// ------------------------------------------------------------
// Extend buff item controller with cached tint widgets
// ------------------------------------------------------------
@addField(buffListItemLogicController)
private let m_tintWidgetsCached: Bool;

@addField(buffListItemLogicController)
private let m_isDebuffCached: Bool;

@addField(buffListItemLogicController)
private let m_glow: wref<inkImage>;

@addField(buffListItemLogicController)
private let m_iconImg: wref<inkImage>;

@addField(buffListItemLogicController)
private let m_shadow: wref<inkImage>;

@addField(buffListItemLogicController)
private let m_iconBgImg: wref<inkImage>;

@addField(buffListItemLogicController)
private let m_frame: wref<inkImage>;

@addField(buffListItemLogicController)
private let m_frameBG: wref<inkImage>;

@addField(buffListItemLogicController)
private let m_timeText: wref<inkText>;

@addField(buffListItemLogicController)
private let m_counterBG: wref<inkImage>;

// ------------------------------------------------------------
// Add color setter with caching + guard
// ------------------------------------------------------------
@addMethod(buffListItemLogicController)
private final func SetBuffTint(isDebuff: Bool) -> Void {

  // Skip if state didn't change
  if this.m_tintWidgetsCached && Equals(this.m_isDebuffCached, isDebuff) {
    return;
  };

  // Cache widgets once
  if !this.m_tintWidgetsCached {
    let root = this.GetRootCompoundWidget() as inkCompoundWidget;

    this.m_glow = root.GetWidget(n"buffCanvas/fg/glow") as inkImage;
    this.m_iconImg = root.GetWidget(n"buffCanvas/fg/icon") as inkImage;
    this.m_shadow = root.GetWidget(n"buffCanvas/fg/shadow") as inkImage;
    this.m_frame = root.GetWidget(n"buffCanvas/fg/frame") as inkImage;
    this.m_iconBgImg = root.GetWidget(n"buffCanvas/bg/icon") as inkImage;
    this.m_frameBG = root.GetWidget(n"buffCanvas/bg/frame") as inkImage;
    this.m_timeText = root.GetWidget(n"timer") as inkText;
    this.m_counterBG = root.GetWidget(n"buffCanvas/CounterCanvas/counterBg") as inkImage;

    this.m_glow.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_iconImg.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_shadow.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_frame.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_iconBgImg.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_frameBG.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_timeText.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");
    this.m_counterBG.SetStyle(r"base\\gameplay\\gui\\common\\main_colors.inkstyle");

    this.m_tintWidgetsCached = true;
  };

  // Apply tint
  if isDebuff {
    this.m_glow.BindProperty(n"tintColor", n"MainColors.Red"); //Red
    this.m_shadow.BindProperty(n"tintColor", n"MainColors.Black");
    this.m_iconImg.BindProperty(n"tintColor", n"MainColors.Red"); //Red
    this.m_iconBgImg.BindProperty(n"tintColor", n"MainColors.Red"); //Grey
    this.m_frame.BindProperty(n"tintColor", n"MainColors.ActiveRed"); //ActiveRed
    this.m_frameBG.BindProperty(n"tintColor", n"MainColors.DarkRed"); //ActiveBlue
    this.m_timeText.BindProperty(n"tintColor", n"MainColors.Red"); //Red
    this.m_counterBG.BindProperty(n"tintColor", n"MainColors.Red"); //Red
  } else {
    this.m_glow.BindProperty(n"tintColor", n"MainColors.Blue"); //Blue
    this.m_shadow.BindProperty(n"tintColor", n"MainColors.Black");
    this.m_iconImg.BindProperty(n"tintColor", n"MainColors.Blue"); //Blue
    this.m_iconBgImg.BindProperty(n"tintColor", n"MainColors.Blue"); //Grey
    this.m_frame.BindProperty(n"tintColor", n"MainColors.ActiveBlue"); //ActiveBlue
    this.m_frameBG.BindProperty(n"tintColor", n"MainColors.DarkBlue"); //DarkBlue
    this.m_timeText.BindProperty(n"tintColor", n"MainColors.Blue"); //Blue
    this.m_counterBG.BindProperty(n"tintColor", n"MainColors.Blue"); //Blue
  };

  this.m_isDebuffCached = isDebuff;
}

// ------------------------------------------------------------
// Hook buff list update and apply tint
// ------------------------------------------------------------
@wrapMethod(buffListGameController)
private final func UpdateBuffDebuffList() -> Void {
  wrappedMethod();

  let buffCount: Int32 = ArraySize(this.m_buffDataList);
  let i: Int32 = 0;
  let widget: wref<inkWidget>;
  let controller: wref<buffListItemLogicController>;
  let isDebuff: Bool;

  while i < inkCompoundRef.GetNumChildren(this.m_buffsList) {
    widget = this.m_buffWidgets[i];
    controller = widget.GetController() as buffListItemLogicController;

    if IsDefined(controller) {
      // Buffs first, debuffs appended after
      isDebuff = i >= buffCount;
      controller.SetBuffTint(isDebuff);
    };
    i += 1;
  };
}
