// Stamina Consumption Fix v1.0.0
@addField(LocomotionEventsTransition)
let consumptionTimeDelta: Float;
@wrapMethod(LocomotionEventsTransition)
private final func OnUpdate(timeDelta: Float, stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    // We grab the time delta here because we'll need it later when
    // CDPR's SpaghettiAlSoleDiSsorrento.script deigns to call ConsumeStaminaBasedOnLocomotionState
    this.consumptionTimeDelta = timeDelta * 60.0; // scaled to 60fps as reference 1 = 1 frame
    wrappedMethod(timeDelta, stateContext, scriptInterface);
}
@replaceMethod(LocomotionEventsTransition)
private final func ConsumeStaminaBasedOnLocomotionState(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    // This is equivalent to the original, but we do scale consumption over time values by the time delta.
    // Note that some consumption (like dodging) only happens once, rather than over time, so we need to 
    // consider it on a per-case basis.
    let consumptionState = this.GetStateName();
    let staminaConsumption: Float = 0;
    switch (consumptionState) {
        case n"sprint":
            if( !( RPGManager.HasStatFlag( scriptInterface.executionOwner, gamedataStatType.IsSprintStaminaFree ) ) )
            {
                staminaConsumption = PlayerStaminaHelpers.GetSprintStaminaCost();
                staminaConsumption *= this.consumptionTimeDelta;
            }
        break;
        case n"crouchSprint":
            staminaConsumption = PlayerStaminaHelpers.GetCrouchSprintStaminaCost();
            let hasCrouchSprintPerk = PlayerDevelopmentSystem.GetInstance(scriptInterface.executionOwner).IsNewPerkBought( scriptInterface.executionOwner, gamedataNewPerkType.Cool_Central_Perk_3_4 ) == 1;
            let isInCombat = Equals(scriptInterface.localBlackboard.GetInt(GetAllBlackboardDefs().PlayerStateMachine.Combat), EnumInt(gamePSMCombat.InCombat));
            if (hasCrouchSprintPerk && isInCombat) {
                staminaConsumption *= TweakDBInterface.GetFloat(t"NewPerks.Cool_Central_Perk_3_4.crouchSprintStaminaCostMultiplier", 1.0);
            }
            let staminaReductionMultiplier = scriptInterface.GetStatsSystem().GetStatValue(Cast<StatsObjectID>(scriptInterface.executionOwner.GetEntityID()), gamedataStatType.CrouchSprintStaminaCostReduction);
            if( staminaReductionMultiplier > 0.0 )
            {
                staminaConsumption *= ( 1.0 - staminaReductionMultiplier );
            }
            staminaConsumption *= this.consumptionTimeDelta;
        break;
        case n"swimmingSurfaceFast":
        case n"swimmingFastDiving":
            staminaConsumption = PlayerStaminaHelpers.GetSprintStaminaCost();
            staminaConsumption *= this.consumptionTimeDelta;
        break;
        case n"slide":
            staminaConsumption = PlayerStaminaHelpers.GetSlideStaminaCost();
            staminaConsumption *= this.consumptionTimeDelta;
        break;
        case n"jump":
        case n"doubleJump":
        case n"chargeJump":
        case n"hoverJump":
            staminaConsumption = PlayerStaminaHelpers.GetJumpStaminaCost();
        break;
        case n"dodge":
            if( !( RPGManager.HasStatFlag( scriptInterface.executionOwner, gamedataStatType.IsDodgeStaminaFree ) ) )
            {
                if( this.IsTouchingGround( scriptInterface ) ){
                    staminaConsumption = PlayerStaminaHelpers.GetDodgeStaminaCost();
                } else {
                    staminaConsumption = PlayerStaminaHelpers.GetAirDodgeStaminaCost();
                }
                let staminaReductionMultiplier = scriptInterface.GetStatsSystem().GetStatValue(Cast<StatsObjectID>(scriptInterface.executionOwner.GetEntityID()), gamedataStatType.DodgeStaminaCostReduction );
                if( staminaReductionMultiplier > 0.0 ) {
                    staminaConsumption *= ( 1.0 - staminaReductionMultiplier );
                }
            }
        break;
        case n"dodgeAir":
            if( !( RPGManager.HasStatFlag( scriptInterface.executionOwner, gamedataStatType.IsDodgeStaminaFree ) ) ) {
                staminaConsumption = PlayerStaminaHelpers.GetAirDodgeStaminaCost();
                let staminaReductionMultiplier = scriptInterface.GetStatsSystem().GetStatValue(Cast<StatsObjectID>(scriptInterface.executionOwner.GetEntityID()), gamedataStatType.DodgeStaminaCostReduction );
                if( staminaReductionMultiplier > 0.0 ) {
                    staminaConsumption *= ( 1.0 - staminaReductionMultiplier );
                }
            }
        break;
        default:
            staminaConsumption = 0.1;
        break;
    }
    // just zero it to protect against repeated calls
    this.consumptionTimeDelta = 0;
    if( staminaConsumption > 0.0 ) {
        PlayerStaminaHelpers.ModifyStamina(scriptInterface.executionOwner as PlayerPuppet, -staminaConsumption);
    }
}
