// You should be using this if you are NOT using the Limited HUD mod.
@replaceMethod(NameplateVisualsLogicController)
private final func UpdateHealthbarVisibility() -> Void {
  let playerPuppet: wref<PlayerPuppet>;
  let threatPuppet: wref<NPCPuppet>;
  let hpVisible: Bool = this.m_npcIsAggressive;
  let nameplateHpVisible: Bool = hpVisible && !this.m_isBoss;
  if NotEquals(this.m_healthbarVisible, nameplateHpVisible) {
    this.m_healthbarVisible = nameplateHpVisible;
    inkWidgetRef.SetVisible(this.m_healthbarWidget, this.m_healthbarVisible);
  };
  if this.m_isBoss && IsDefined(this.m_cachedPuppet) {
    playerPuppet = GetPlayer(this.m_cachedPuppet.GetGame());
    threatPuppet = this.m_cachedPuppet as NPCPuppet;
    if ScriptedPuppet.IsAlive(threatPuppet) && hpVisible && !ScriptedPuppet.IsDefeated(threatPuppet) {
      BossHealthBarGameController.ReevaluateBossHealthBar(threatPuppet, playerPuppet);
    };
  };
}