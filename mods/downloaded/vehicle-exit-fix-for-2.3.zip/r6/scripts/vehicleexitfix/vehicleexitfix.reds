@replaceMethod(VehicleComponent)
private final func SendAIEvent(eventName: CName) -> Void {
  let evt: ref<AIEvent>;
  if !IsNameValid(eventName) || Equals(eventName, n"NoDriver") {
    return;
  }
  evt = new AIEvent();
  evt.name = eventName;
  this.GetVehicle().QueueEvent(evt);
}

/*
You're thinking "you idiot - why didnt you just @replaceMethod OnUnmountingEvent() where 'NoDriver' is actually sent from instead of messing with a utility function?
because:
- @replaceMethod'ing that func means only one mod can do it and any and all mods that @wrapMethod it wont work. So any mod that wraps unmount (which many mods are) would stop working/conficts with this mod
- SendAIEvent() was added in 2.3 and is only used in 2 places (also added in 2.3) and seems like more of a failsafe. On testing it seems like the car stops fine even without this ai event and it just causes this unncessary jerk on stop.
*/