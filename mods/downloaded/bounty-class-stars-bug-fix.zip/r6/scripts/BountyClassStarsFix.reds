@replaceMethod(NPCPuppet)
  public const func CompileScannerChunks() -> Bool {
    let NPCName: String;
    let abilities: array<wref<GameplayAbility_Record>>;
    let abilityChunk: ref<ScannerAbilities>;
    let abilityGroups: array<wref<GameplayAbilityGroup_Record>>;
    let abilityItem: wref<GameplayAbility_Record>;
    let abilityUIValidationPrereqs: array<wref<IPrereq_Record>>;
    let ap: ref<AccessPointControllerPS>;
    let archetypeData: wref<ArchetypeData_Record>;
    let archetypeName: CName;
    let archtypeChunk: ref<ScannerArchetype>;
    let attitudeChunk: ref<ScannerAttitude>;
    let availablePlayerActions: array<TweakDBID>;
    let basicWeaponChunk: ref<ScannerWeaponBasic>;
    let bounty: Bounty;
    let bountyChunk: ref<ScannerBountySystem>;
    let bountyUI: BountyUI;
    let choices: array<InteractionChoice>;
    let context: GetActionsContext;
    let detailedWeaponChunk: ref<ScannerWeaponDetailed>;
    let enemyDifficulty: gameEPowerDifferential;
    let factionChunk: ref<ScannerFaction>;
    let hasLinkToDB: Bool;
    let healthChunk: ref<ScannerHealth>;
    let i: Int32;
    let items: array<wref<NPCEquipmentItem_Record>>;
    let k: Int32;
    let levelChunk: ref<ScannerLevel>;
    let nameChunk: ref<ScannerName>;
    let nameParams: ref<inkTextParams>;
    let networkStatusChunk: ref<ScannerNetworkStatus>;
    let puppetQuickHack: wref<ObjectAction_Record>;
    let quickHackActionRecords: array<wref<ObjectAction_Record>>;
    let rarityChunk: ref<ScannerRarity>;
    let resistancesChunk: ref<ScannerResistances>;
    let resists: array<ScannerStatDetails>;
    let scannerBlackboard: wref<IBlackboard>;
    let shouldShowInUIAccordingToAbilityPrereqs: Bool;
    let statPoolSystem: ref<StatPoolsSystem>;
    let vulnerabilitiesChunk: ref<ScannerVulnerabilities>;
    let vulnerability: Vulnerability;
    let z: Int32;
    let ps: ref<ScriptedPuppetPS> = this.GetPS();
    let characterRecord: ref<Character_Record> = TweakDBInterface.GetCharacterRecord(this.GetRecordID());
    let scannerPreset: ref<ScannerModuleVisibilityPreset_Record> = characterRecord.ScannerModulePreset();
    let thisEntity: ref<GameObject> = EntityGameInterface.GetEntity(this.GetEntity()) as GameObject;
    if TDBID.IsValid(ps.GetForcedScannerPreset()) {
      scannerPreset = TweakDBInterface.GetScannerModuleVisibilityPresetRecord(ps.GetForcedScannerPreset());
    } else {
      scannerPreset = characterRecord.ScannerModulePreset();
    };
    scannerBlackboard = GameInstance.GetBlackboardSystem(this.GetGame()).Get(GetAllBlackboardDefs().UI_ScannerModules);
    if !IsDefined(characterRecord) || !IsDefined(scannerPreset) || !IsDefined(scannerBlackboard) {
      return false;
    };
    scannerBlackboard.SetInt(GetAllBlackboardDefs().UI_ScannerModules.ObjectType, 1, true);
    if scannerPreset.ShoulShowName() {
      nameChunk = new ScannerName();
      archetypeName = characterRecord.ArchetypeData().Type().LocalizedName();
      if NotEquals(archetypeName, n"None") && !characterRecord.SkipDisplayArchetype() {
        nameChunk.SetArchetype(true);
      };
      nameParams = new inkTextParams();
      if ps.HasAlternativeName() {
        if IsNameValid(characterRecord.AlternativeFullDisplayName()) {
          NPCName = LocKeyToString(characterRecord.AlternativeFullDisplayName());
        } else {
          NPCName = LocKeyToString(characterRecord.AlternativeDisplayName());
        };
      } else {
        if this.IsCharacterCivilian() || Equals(characterRecord.BaseAttitudeGroup(), n"child_ow") {
          if IsNameValid(characterRecord.DisplayName()) {
            NPCName = LocKeyToString(characterRecord.DisplayName());
          } else {
            NPCName = this.GetDisplayName();
          };
        } else {
          if IsNameValid(characterRecord.FullDisplayName()) {
            NPCName = LocKeyToString(characterRecord.FullDisplayName());
          } else {
            if IsNameValid(characterRecord.DisplayName()) {
              NPCName = LocKeyToString(characterRecord.DisplayName());
            } else {
              NPCName = this.GetDisplayName();
            };
          };
        };
      };
      if nameChunk.HasArchetype() {
        nameParams = new inkTextParams();
        if Equals(NPCName, ToString(archetypeName)) || !IsNameValid(characterRecord.FullDisplayName()) && !IsNameValid(characterRecord.DisplayName()) {
          NPCName = "";
        };
        nameParams.AddLocalizedString("TEXT_PRIMARY", NPCName);
        nameParams.AddLocalizedString("TEXT_SECONDARY", ToString(archetypeName));
        nameChunk.SetTextParams(nameParams);
        archtypeChunk = new ScannerArchetype();
        archtypeChunk.Set(characterRecord.ArchetypeData().Type().Type());
        scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerArchetype, ToVariant(archtypeChunk));
      } else {
        nameChunk.Set(NPCName);
      };
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerName, ToVariant(nameChunk));
    };
    if scannerPreset.ShouldShowLevel() {
      levelChunk = new ScannerLevel();
      levelChunk.Set(0);
      levelChunk.SetIndicator(NPCPuppet.ShouldShowIndicator(thisEntity));
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerLevel, ToVariant(levelChunk));
    };
    if scannerPreset.ShouldShowRarity() {
      rarityChunk = new ScannerRarity();
      hasLinkToDB = GameInstance.GetStatsSystem(this.GetGame()).GetStatValue(Cast<StatsObjectID>(GetPlayer(this.GetGame()).GetEntityID()), gamedataStatType.HasLinkToBountySystem) > 0.00;
      rarityChunk.Set(this.GetNPCRarity(), this.IsCharacterCivilian() && hasLinkToDB);
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerRarity, ToVariant(rarityChunk));
    };
    if scannerPreset.ShouldShowFaction() {
      factionChunk = new ScannerFaction();
      factionChunk.Set(LocKeyToString(characterRecord.Affiliation().LocalizedName()));
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerFaction, ToVariant(factionChunk));
    };
    if !this.IsDead() && !ScriptedPuppet.IsDefeated(this) && scannerPreset.ShouldShowAttitude() {
      attitudeChunk = new ScannerAttitude();
      attitudeChunk.Set(this.GetAttitudeTowards(GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerControlledGameObject()));
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerAttitude, ToVariant(attitudeChunk));
    };
    if scannerPreset.ShouldShowHealth() {
      healthChunk = new ScannerHealth();
      statPoolSystem = GameInstance.GetStatPoolsSystem(this.GetGame());
      if IsDefined(statPoolSystem) {
        healthChunk.Set(Cast<Int32>(statPoolSystem.GetStatPoolValue(Cast<StatsObjectID>(this.GetEntityID()), gamedataStatPoolType.Health, false)), Cast<Int32>(GameInstance.GetStatPoolsSystem(this.GetGame()).GetStatPoolMaxPointValue(Cast<StatsObjectID>(this.GetEntityID()), gamedataStatPoolType.Health)));
        scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerHealth, ToVariant(healthChunk));
      };
    };
    if scannerPreset.ShouldShowBounty() && TDBID.IsValid(this.GetRecord().BountyDrawTable().GetID()) && !this.m_bounty.m_filteredOut {
      if ArraySize(this.m_bounty.m_transgressions) <= 0 {
        bounty = BountyManager.GenerateBounty(this);
      } else {
        bounty = this.m_bounty;
      };
      if !bounty.m_filteredOut {
        bountyChunk = new ScannerBountySystem();
        bountyUI.issuedBy = LocKeyToString(TweakDBInterface.GetAffiliationRecord(bounty.m_bountySetter).LocalizedName());
        bountyUI.moneyReward = bounty.m_moneyAmount;
        bountyUI.streetCredReward = bounty.m_streetCredAmount;
        switch this.GetNPCRarity() {
          case gamedataNPCRarity.Trash:
            bountyUI.level = 1;
            break;
          case gamedataNPCRarity.Weak:
            bountyUI.level = 1;
            break;
          case gamedataNPCRarity.Normal:
            bountyUI.level = 2;
            break;
          case gamedataNPCRarity.Rare:
            bountyUI.level = 3;
            break;
          case gamedataNPCRarity.Officer:
            bountyUI.level = 4;
            break;
          case gamedataNPCRarity.Elite:
            bountyUI.level = 4;
            break;
          case gamedataNPCRarity.Boss:
            bountyUI.level = 5;
            break;
          default:
            bountyUI.level = 1;
            break;
        };
        bountyUI.hasAccess = GameInstance.GetStatsSystem(this.GetGame()).GetStatValue(Cast<StatsObjectID>(GetPlayer(this.GetGame()).GetEntityID()), gamedataStatType.HasLinkToBountySystem) > 0.00;
        i = 0;
        while i < ArraySize(bounty.m_transgressions) {
          ArrayPush(bountyUI.transgressions, TweakDBInterface.GetTransgressionRecord(bounty.m_transgressions[i]).LocalizedDescription());
          i += 1;
        };
        bountyChunk.Set(bountyUI);
        scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerBountySystem, ToVariant(bountyChunk));
      };
    };
    if !this.IsDead() && !ScriptedPuppet.IsDefeated(this) && scannerPreset.ShouldShowWeaponData() {
      AIActionTransactionSystem.CalculateEquipmentItems(this, this.GetRecord().PrimaryEquipment(), items, -1);
      basicWeaponChunk = new ScannerWeaponBasic();
      basicWeaponChunk.Set(items[0].Item().DisplayName());
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerWeaponBasic, ToVariant(basicWeaponChunk));
    };
    if !this.IsDead() && !ScriptedPuppet.IsDefeated(this) && scannerPreset.ShouldShowVulnerabilities() {
      vulnerabilitiesChunk = new ScannerVulnerabilities();
      availablePlayerActions = RPGManager.GetPlayerQuickHackList(GetPlayer(this.GetGame()));
      context = ps.GenerateContext(gamedeviceRequestType.Remote, Device.GetInteractionClearance(), Device.GetPlayerMainObjectStatic(this.GetGame()), this.GetEntityID());
      ArrayResize(quickHackActionRecords, ArraySize(availablePlayerActions));
      i = 0;
      while i < ArraySize(availablePlayerActions) {
        quickHackActionRecords[i] = TweakDBInterface.GetObjectActionRecord(availablePlayerActions[i]);
        i += 1;
      };
      ps.GetValidChoices(quickHackActionRecords, context, null, false, choices);
      i = 0;
      while i < ArraySize(choices) {
        k = 0;
        while k < ArraySize(choices[i].data) {
          puppetQuickHack = FromVariant<ref<ScriptableDeviceAction>>(choices[i].data[k]).GetObjectActionRecord();
          if IsDefined(puppetQuickHack) {
            vulnerability.vulnerabilityName = puppetQuickHack.ObjectActionUI().Caption();
            vulnerability.icon = puppetQuickHack.ObjectActionUI().CaptionIcon().TexturePartID().GetID();
            z = 0;
            while z < ArraySize(quickHackActionRecords) {
              if quickHackActionRecords[z].GameplayCategory().GetID() == puppetQuickHack.GetID() {
                vulnerability.isActive = true;
              };
              z += 1;
            };
            vulnerabilitiesChunk.PushBack(vulnerability);
          };
          k += 1;
        };
        i += 1;
      };
      if vulnerabilitiesChunk.IsValid() {
        scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerVulnerabilities, ToVariant(vulnerabilitiesChunk));
      };
    };
    if scannerPreset.ShouldShowNetworkStatus() {
      networkStatusChunk = new ScannerNetworkStatus();
      ap = ps.GetAccessPoint();
      if IsDefined(ap) {
        if ap.IsBreached() {
          networkStatusChunk.Set(ScannerNetworkState.BREACHED);
        } else {
          networkStatusChunk.Set(ScannerNetworkState.NOT_BREACHED);
        };
      } else {
        networkStatusChunk.Set(ScannerNetworkState.NOT_CONNECTED);
      };
    };
    if !this.IsDead() && !ScriptedPuppet.IsDefeated(this) && scannerPreset.ShouldShowResistances() {
      resistancesChunk = new ScannerResistances();
      ArrayPush(resists, RPGManager.GetScannerResistanceDetails(thisEntity, gamedataStatType.PhysicalResistance));
      ArrayPush(resists, RPGManager.GetScannerResistanceDetails(thisEntity, gamedataStatType.ThermalResistance));
      ArrayPush(resists, RPGManager.GetScannerResistanceDetails(thisEntity, gamedataStatType.ElectricResistance));
      ArrayPush(resists, RPGManager.GetScannerResistanceDetails(thisEntity, gamedataStatType.ChemicalResistance));
      ArrayPush(resists, RPGManager.GetScannerResistanceDetails(thisEntity, gamedataStatType.HackingResistance, GameInstance.GetPlayerSystem(this.GetGame()).GetLocalPlayerMainGameObject()));
      resistancesChunk.Set(resists);
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerResistances, ToVariant(resistancesChunk));
    };
    if !this.IsDead() && !ScriptedPuppet.IsDefeated(this) {
      abilityChunk = new ScannerAbilities();
      archetypeData = characterRecord.ArchetypeData();
      if !IsDefined(archetypeData) {
        return false;
      };
      if archetypeData.GetAbilityGroupsCount() > 0 {
        archetypeData.AbilityGroups(abilityGroups);
        i = 0;
        while i < ArraySize(abilityGroups) {
          abilityGroups[i].Abilities(abilities);
          i += 1;
        };
      };
      i = 0;
      while i < characterRecord.GetAbilitiesCount() {
        abilityItem = characterRecord.GetAbilitiesItem(i);
        if !ArrayContains(abilities, abilityItem) {
          ArrayPush(abilities, abilityItem);
        };
        i += 1;
      };
      i = ArraySize(abilities) - 1;
      while i >= 0 {
        abilityItem = abilities[i];
        abilityItem.PrereqsForUIValidation(abilityUIValidationPrereqs);
        shouldShowInUIAccordingToAbilityPrereqs = false;
        k = 0;
        while k < ArraySize(abilityUIValidationPrereqs) {
          shouldShowInUIAccordingToAbilityPrereqs = IPrereq.CreatePrereq(abilityUIValidationPrereqs[k].GetID()).IsFulfilled(this.GetGame(), this);
          if !shouldShowInUIAccordingToAbilityPrereqs {
            ArrayRemove(abilities, abilityItem);
            break;
          };
          k += 1;
        };
        ArrayClear(abilityUIValidationPrereqs);
        i -= 1;
      };
      abilityChunk.Set(abilities);
      scannerBlackboard.SetVariant(GetAllBlackboardDefs().UI_ScannerModules.ScannerAbilities, ToVariant(abilityChunk));
    };
    return true;
  }
