@replaceMethod(MeleeTransition)
protected final const func IsBlockHeld(
  const stateContext: ref<StateContext>,
  const scriptInterface: ref<StateGameScriptInterface>
) -> Bool {
  if scriptInterface.localBlackboard.GetInt(
    GetAllBlackboardDefs().PlayerStateMachine.UpperBody
  ) == 6 {
    return true;
  };

  let weapon: ref<WeaponObject> = MeleeTransition.GetWeaponObject(scriptInterface);

  if IsDefined(weapon) && weapon.WeaponHasTag(n"Throwable") {
    if scriptInterface.GetActionValue(n"MeleeBlock") > 0.50 {
      return true;
    };
  };

  return false;
}
