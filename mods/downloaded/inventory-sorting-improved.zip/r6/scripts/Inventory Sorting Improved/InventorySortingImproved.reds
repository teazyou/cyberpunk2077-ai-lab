module InventorySortingImproved

//Mod Settings Menu and Cyberware sorting adapted from Sort Ripperdoc Inventory by v1ld
enum PrimaryKey {
  Name = 0,
  Quality = 1,
}

enum SortDirection {
  Ascending = 0,
  Descending = 1,
}

class Settings extends ScriptableSystem {
  @runtimeProperty("ModSettings.mod", "Cyberware Inventory Sorting")
  @runtimeProperty("ModSettings.displayName", "Enable")
  @runtimeProperty("ModSettings.description", "Enable or disable.")
  let enabled: Bool = true;

  @runtimeProperty("ModSettings.mod", "Cyberware Inventory Sorting")
  @runtimeProperty("ModSettings.displayName", "Sort first by")
  @runtimeProperty("ModSettings.description", "Sort first by either Name or Quality, then the other.")
  @runtimeProperty("ModSettings.displayValues", "\"Name\", \"Quality\"")
  @runtimeProperty("ModSettings.dependency", "enabled")
  let primaryKey: PrimaryKey = PrimaryKey.Name;

  @runtimeProperty("ModSettings.mod", "Cyberware Inventory Sorting")
  @runtimeProperty("ModSettings.displayName", "Name sort order")
  @runtimeProperty("ModSettings.description", "Sort Names in ascending or descending order.")
  @runtimeProperty("ModSettings.displayValues", "\"Ascending\", \"Descending\"")
  @runtimeProperty("ModSettings.dependency", "enabled")
  let nameOrder: SortDirection = SortDirection.Ascending;

  @runtimeProperty("ModSettings.mod", "Cyberware Inventory Sorting")
  @runtimeProperty("ModSettings.displayName", "Quality sort order")
  @runtimeProperty("ModSettings.description", "Sort Qualities in ascending or descending order.")
  @runtimeProperty("ModSettings.displayValues", "\"Ascending\", \"Descending\"")
  @runtimeProperty("ModSettings.dependency", "enabled")
  let qualityOrder: SortDirection = SortDirection.Descending;

  /* Mod Settings helpers & listeners */
  public static func Get(gi: GameInstance) -> ref<Settings> {
    return GameInstance
      .GetScriptableSystemsContainer(gi)
      .Get(n"InventorySortingImproved.Settings") as Settings;
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnAttach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }

  @if(ModuleExists("ModSettingsModule"))
  private func OnDetach() -> Void {
    ModSettings.RegisterListenerToClass(this);
  }
}

@replaceMethod(NewItemCompareBuilder)
public final func QualityAsc() -> ref<NewItemCompareBuilder> {
  this
    .m_compareBuilder
    .FloatAsc(
      UIItemsHelper.GetQualityF(this.m_sortData1.GetRealItemData()),
      UIItemsHelper.GetQualityF(this.m_sortData2.GetRealItemData())
    );
  return this;
}

@replaceMethod(NewItemCompareBuilder)
public final func QualityDesc() -> ref<NewItemCompareBuilder> {
  this
    .m_compareBuilder
    .FloatDesc(
      UIItemsHelper.GetQualityF(this.m_sortData1.GetRealItemData()),
      UIItemsHelper.GetQualityF(this.m_sortData2.GetRealItemData())
    );
  return this;
}

@wrapMethod(ItemCompareBuilder)
public final static func BuildInventoryItemSortData(const item: script_ref<InventoryItemData>, uiScriptableSystem: ref<UIScriptableSystem>) -> InventoryItemSortData {
  let sortData = wrappedMethod(item, uiScriptableSystem);
  sortData.Quality = RoundF(UIItemsHelper.GetQualityF(item) * 100.0);
  return sortData;
}

//overrides weapon inventory default sorting, originally in Better Quality Sort by Emil8000
@wrapMethod(ItemModeGridView)
public func SortItem(left: ref<IScriptable>, right: ref<IScriptable>) -> Bool {
  if Equals(this.m_itemSortMode, ItemSortMode.Default) {
    this.m_itemSortMode = ItemSortMode.QualityAsc;
  }
  return wrappedMethod(left, right);
}

public class QuicksortUIInventoryItem extends IScriptable {
  public final static func Sort(
    items: script_ref<[wref<UIInventoryItem>]>,
    comparator: ref<UIInventoryItemMultiComparator>,
    leftIndex: Int32,
    rightIndex: Int32
  ) -> Void {
    let index: Int32;
    if ArraySize(Deref(items)) > 1 {
      index = QuicksortUIInventoryItem.Partition(items, comparator, leftIndex, rightIndex);
      if leftIndex < index - 1 {
        QuicksortUIInventoryItem.Sort(items, comparator, leftIndex, index - 1);
      }
      if index < rightIndex {
        QuicksortUIInventoryItem.Sort(items, comparator, index, rightIndex);
      }
    }
  }

  private final static func Partition(
    items: script_ref<[wref<UIInventoryItem>]>,
    comparator: ref<UIInventoryItemMultiComparator>,
    leftIndex: Int32,
    rightIndex: Int32
  ) -> Int32 {
    let tempItem: ref<UIInventoryItem>;
    let i: Int32 = leftIndex;
    let j: Int32 = rightIndex;

    let pivot: wref<UIInventoryItem> = Deref(items)[FloorF((Cast<Float>(rightIndex) + Cast<Float>(leftIndex)) / 2.0)];
    while i <= j {
      while comparator.Compare(Deref(items)[i], pivot) > 0 {
        i += 1;
      }
      while comparator.Compare(Deref(items)[j], pivot) < 0 {
        j -= 1;
      }
      if i <= j {
        tempItem = Deref(items)[i];
        Deref(items)[i] = Deref(items)[j];
        Deref(items)[j] = tempItem;
        i += 1;
        j -= 1;
      }
    }
    return i;
  }
}

// A custom comparator to sort UIInventoryItems using multi-level logic
public class UIInventoryItemMultiComparator extends IScriptable {
  // Storing a reference to the settings is the simplest way of passing them down from the wrapper
  let settings: wref<Settings>;

  public static func Make(settings: wref<Settings>) -> ref<UIInventoryItemMultiComparator> {
    let self = new UIInventoryItemMultiComparator();
    self.settings = settings;
    return self;
  }

  public func Compare(const item1: wref<UIInventoryItem>, const item2: wref<UIInventoryItem>) -> Int32 {
    let leftItem = item1;
    let rightItem = item2;

    let leftName = leftItem.GetName();
    let rightName = rightItem.GetName();

    let mkSubstr: String = "mk.";

    if leftItem.IsCyberdeck() {
      let leftMkIndex = StrFindLast(StrLower(leftName), mkSubstr);
      if leftMkIndex != -1 {
        leftName = StrMid(AsRef(leftName), 0, leftMkIndex);
      }
    }

    if rightItem.IsCyberdeck() {
      let rightMkIndex = StrFindLast(StrLower(rightName), mkSubstr);
      if rightMkIndex != -1 {
        rightName = StrMid(AsRef(rightName), 0, rightMkIndex);
      }
    }

    let leftItemQuality = UIItemsHelper
      .GetQualityF(leftItem.GetQualityInt(), leftItem.IsIconic(), leftItem.GetItemPlus());
    let rightItemQuality = UIItemsHelper
      .GetQualityF(rightItem.GetQualityInt(), rightItem.IsIconic(), rightItem.GetItemPlus());

    let sortByName = StrCmp(rightName, leftName) * (Equals(this.settings.nameOrder, SortDirection.Ascending) ? 1 : -1);
    let sortByQuality = RoundF((rightItemQuality - leftItemQuality) * 100.0) * (Equals(this.settings.qualityOrder, SortDirection.Ascending) ? 1 : -1);

    let result = 0;
    if Equals(this.settings.primaryKey, PrimaryKey.Name) {
      result = sortByName != 0 ? sortByName : sortByQuality;
    } else {
      result = sortByQuality != 0 ? sortByQuality : sortByName;
    }

    return result;
  }
}

@wrapMethod(RipperDocGameController)
private final func PreparePlayerItems() -> Void {
  wrappedMethod();

  let settings = Settings.Get(this.m_player.GetGame());
  if settings.enabled {
    let comparator = UIInventoryItemMultiComparator.Make(settings);
    let i = 0;
    let limit = ArraySize(this.m_cachedPlayerItems);
    while i < limit {
      // Check if there's anything to sort (avoids work on empty categories)
      if ArraySize(this.m_cachedPlayerItems[i]) > 1 {
        QuicksortUIInventoryItem
          .Sort(
            AsRef(this.m_cachedPlayerItems[i]),
            comparator,
            0,
            ArraySize(this.m_cachedPlayerItems[i]) - 1
          );
      }
      i += 1;
    }
  }
}

