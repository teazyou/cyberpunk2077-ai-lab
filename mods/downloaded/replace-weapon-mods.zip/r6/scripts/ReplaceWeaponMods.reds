module ReplaceWeaponMods

public class ReplaceWeaponModsSettings {
  @runtimeProperty("ModSettings.mod", "Replace Weapon Mods")
  @runtimeProperty("ModSettings.displayName", "Mod-Replace-Weapon-Mods-Display-Warning-Name")
  @runtimeProperty("ModSettings.description", "Mod-Replace-Weapon-Mods-Display-Warning-Desc")
  let showWarning: Bool = true;
}

@replaceMethod(InventoryItemModeLogicController)
protected cb func OnReplaceModNotificationClosed(data: ref<inkGameNotificationData>) -> Bool {
  let closeData: ref<GenericMessageNotificationCloseData> = data as GenericMessageNotificationCloseData;
  this.m_replaceModNotification = null;
  if IsDefined(closeData) && Equals(closeData.result, GenericMessageNotificationResult.Yes) {
    this.RemoveRetrievableParts(this.m_installModData.slotID);
    this.m_InventoryManager.InstallPart(this.m_installModData.itemId, this.m_installModData.partId, this.m_installModData.slotID);
    this.TelemetryLogPartInstalled(this.m_installModData.telemetryItemData, this.m_installModData.telemetryPartData, this.m_installModData.slotID);
  }
  this.m_installModData = null;
}

@addMethod(InventoryItemModeLogicController)
private func RemoveRetrievableParts(slotID: TweakDBID) -> Void {
  let equippedItemData: InventoryItemData = this.itemChooser.GetModifiedItemData();
  let localEquippedData: wref<gameItemData> = InventoryItemData.GetGameItemData(equippedItemData);

  let restoredAttachments: array<ItemAttachments> = RPGManager.GetRetrievableAttachments(localEquippedData);
  for attachment in restoredAttachments {
    if attachment.attachmentSlotID == slotID {
      let transactionSystem: ref<TransactionSystem> = GameInstance.GetTransactionSystem(this.m_player.GetGame());
      let removedID = transactionSystem.RemovePart(this.m_player, localEquippedData.GetID(), attachment.attachmentSlotID);
      if ItemID.IsValid(removedID) {
        transactionSystem.GiveItem(this.m_player, attachment.itemID, 1);
      }
    }
  }
}

@addMethod(InventoryItemModeLogicController)
private func IsPartRetrievable(slotID: TweakDBID) -> Bool {
  let equippedItemData: InventoryItemData = this.itemChooser.GetModifiedItemData();
  let localEquippedData: wref<gameItemData> = InventoryItemData.GetGameItemData(equippedItemData);
  let restoredAttachments: array<ItemAttachments> = RPGManager.GetRetrievableAttachments(localEquippedData);
  for attachment in restoredAttachments {
    if attachment.attachmentSlotID == slotID {
      return true;
    }
  }
  return false;
}

@replaceMethod(InventoryItemModeLogicController)
private final func EquipPart(const itemData: script_ref<InventoryItemData>, slotID: TweakDBID) -> Void {
  let isIconicWeapon: Bool;
  let isPartEquipped: Bool;
  let modItemType: gamedataItemType;
  let equippedItemData: InventoryItemData = this.itemChooser.GetModifiedItemData();
  let localEquippedData: wref<gameItemData> = InventoryItemData.GetGameItemData(equippedItemData);
  if this.m_InventoryManager.CanInstallPart(itemData) {
    modItemType = InventoryItemData.GetItemType(itemData);
    isPartEquipped = localEquippedData.HasPartInSlot(slotID);
    isIconicWeapon = localEquippedData.HasTag(n"IconicWeapon");
    if isPartEquipped && (RPGManager.IsClothingMod(modItemType) || RPGManager.IsWeaponMod(modItemType)) {
      if (isIconicWeapon || new ReplaceWeaponModsSettings().showWarning) && !this.IsPartRetrievable(slotID) {
        this.m_installModData = new InstallModConfirmationData();
        this.m_installModData.itemId = InventoryItemData.GetID(equippedItemData);
        this.m_installModData.partId = InventoryItemData.GetID(itemData);
        this.m_installModData.slotID = slotID;
        this.m_installModData.telemetryItemData = ToTelemetryInventoryItem(equippedItemData);
        this.m_installModData.telemetryPartData = ToTelemetryInventoryItem(itemData);
        this.m_replaceModNotification = GenericMessageNotification.Show(this.m_inventoryController, "Gameplay-Scanning-NPC-Warning", "UI-Notifications-ReplaceMod", GenericMessageNotificationType.YesNo);
        this.m_replaceModNotification.RegisterListener(this, n"OnReplaceModNotificationClosed");
      }
      else {
        this.RemoveRetrievableParts(slotID);
        this.m_InventoryManager.InstallPart(InventoryItemData.GetID(equippedItemData), InventoryItemData.GetID(itemData), slotID);
        this.TelemetryLogPartInstalled(equippedItemData, itemData, slotID);
      }
    } else {
      this.m_InventoryManager.InstallPart(InventoryItemData.GetID(equippedItemData), InventoryItemData.GetID(itemData), slotID);
      this.TelemetryLogPartInstalled(equippedItemData, itemData, slotID);
      this.SetPingTutorialFact(InventoryItemData.GetID(itemData), false);
    }
  }
}

@replaceMethod(InventoryItemModeLogicController)
private final func HandleItemClick(const itemData: script_ref<InventoryItemData>, actionName: ref<inkActionName>, opt displayContext: ItemDisplayContext, opt isPlayerLocked: Bool) -> Void {
  let isClothing: Bool;
  let isEquippedItemBlocked: Bool;
  let item: ItemModParams;
  let localEquippedData: wref<gameItemData>;
  let shouldUpdate: Bool;
  if actionName.IsAction(n"drop_item") {
    if Equals(this.m_playerState, gamePSMVehicle.Default) && !InventoryItemData.IsEquipped(itemData) && RPGManager.CanItemBeDropped(this.m_player, InventoryItemData.GetGameItemData(itemData)) {
      if isPlayerLocked {
        this.ShowNotification(this.m_player.GetGame(), UIMenuNotificationType.InventoryActionBlocked);
        return;
      };
      if InventoryItemData.GetQuantity(itemData) > 1 {
        this.OpenQuantityPicker(itemData, QuantityPickerActionType.Drop);
      } else {
        item.itemID = InventoryItemData.GetID(itemData);
        item.quantity = 1;
        this.AddToDropQueue(item);
        this.RefreshAvailableItems();
        this.PlaySound(n"Item", n"OnDrop");
        this.PlayRumble(RumbleStrength.SuperLight, RumbleType.Pulse, RumblePosition.Right);
      };
    };
  } else {
    if actionName.IsAction(n"preview_item") && (InventoryItemData.IsWeapon(Deref(itemData)) || InventoryItemData.IsGarment(Deref(itemData))) && !InventoryItemData.IsEmpty(itemData) && Equals(displayContext, ItemDisplayContext.Backpack) && this.m_pressedItemDisplay != null {
      this.PlaySound(n"MapPin", n"OnCreate");
      this.m_pressedItemDisplay = null;
      isClothing = this.IsEquipmentAreaClothing(InventoryItemData.GetEquipmentArea(itemData)) || Equals(InventoryItemData.GetEquipmentArea(itemData), gamedataEquipmentArea.Outfit);
      this.m_itemPreviewPopupToken = ItemPreviewHelper.ShowPreviewItem(this, itemData, isClothing, n"OnItemPreviewPopup");
    } else {
      if actionName.IsAction(n"click") && NotEquals(displayContext, ItemDisplayContext.Attachment) && !(InventoryItemData.IsEquipped(itemData) && Equals(this.m_currentHotkey, EHotkey.INVALID)) {
        // localEquippedData = InventoryItemData.GetGameItemData(this.itemChooser.GetModifiedItemData()); // redscript complains about temporary value here despite it being in decompiled code
        let modifiedItemData: InventoryItemData = this.itemChooser.GetModifiedItemData();
        localEquippedData = InventoryItemData.GetGameItemData(modifiedItemData);
        if RPGManager.IsWeaponMod(Deref(itemData).ItemType) && localEquippedData.HasPartInSlot(this.itemChooser.GetSelectedSlotID()) && !localEquippedData.HasTag(n"IconicWeapon") {
          // this.ShowNotification(this.m_player.GetGame(), UIMenuNotificationType.InventoryNoFreeSlot);
          // return;
        };
        shouldUpdate = true;
        isEquippedItemBlocked = localEquippedData.HasTag(n"UnequipBlocked");
        if isEquippedItemBlocked || !InventoryGPRestrictionHelper.CanEquip(itemData, this.m_player) {
          this.ShowNotification(this.m_player.GetGame(), this.DetermineUIMenuNotificationType());
          return;
        };
        if Equals(InventoryItemData.GetItemType(itemData), gamedataItemType.Clo_Outfit) {
          if this.m_outfitInCooldown {
            return;
          };
          if this.ScheduleOutfitCooldownReset() {
            this.SetOutfitCooldown(true);
          };
        };
        this.EquipItem(itemData, this.itemChooser.GetSlotIndex());
        this.PlayRumble(RumbleStrength.Heavy, RumbleType.Pulse, RumblePosition.Right);
        if ArrayContains(this.m_lastEquipmentAreas, gamedataEquipmentArea.Outfit) {
          if NotEquals(this.m_wardrobeSystem.GetActiveClothingSetIndex(), gameWardrobeClothingSetIndex.INVALID) && InventoryItemData.IsEmpty(itemData) {
            shouldUpdate = false;
          };
        };
        this.itemChooser.RefreshItems(shouldUpdate, -1);
        if !InventoryItemData.IsPart(itemData) {
          this.m_viewMode = ItemViewModes.Item;
          this.m_currentFilter = ItemFilterCategory.Invalid;
          this.RefreshAvailableItems();
        };
        this.NotifyItemUpdate();
      };
    };
  };
}