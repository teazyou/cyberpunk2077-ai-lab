@wrapMethod(MeleeTargetingEvents)
  public final func OnCommonExit(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    this.m_aimInTimeRemaining = 0.00;
    this.SetBlackboardFloatVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.AimInTimeRemaining, this.m_aimInTimeRemaining);
    this.ActivateDamageProjection(false, MeleeTransition.GetWeaponObject(scriptInterface), scriptInterface, stateContext);
    if !MeleeTransition.MeleeAttackPressed(scriptInterface) {
      stateContext.SetTemporaryBoolParameter(n"requestKerenzikovDeactivation", true, true);
    };
    // stateContext.SetTemporaryBoolParameter(n"requestKerenzikovDeactivationWithEaseOut", true, true);
  }

@wrapMethod(MeleeThrowAttackEvents)
  public func OnEnter(stateContext: ref<StateContext>, scriptInterface: ref<StateGameScriptInterface>) -> Void {
    let aimAssistRecord: ref<AimAssistMelee_Record> = MeleeTransition.GetAimAssistMeleeRecord(scriptInterface);
    let locomotionState: CName = stateContext.GetStateMachineCurrentState(n"Locomotion");
    this.m_projectileThrown = false;
    if this.CheckItemType(scriptInterface, gamedataItemType.Cyb_NanoWires) {
      this.m_targetObject = this.GetNanoWireTargetObject(scriptInterface);
    };
    this.SetBlackboardIntVariable(scriptInterface, GetAllBlackboardDefs().PlayerStateMachine.MeleeWeapon, 19);
    if IsDefined(aimAssistRecord) && aimAssistRecord.AimSnapOnThrow() {
      scriptInterface.GetTargetingSystem().AimSnap(scriptInterface.executionOwner);
    };
    super.OnEnter(stateContext, scriptInterface);
    if Cast<Bool>(PlayerDevelopmentSystem.GetInstance(scriptInterface.executionOwner).IsNewPerkBought(scriptInterface.executionOwner, gamedataNewPerkType.Cool_Master_Perk_4)) {
      if this.IsInSlidingState(stateContext) || Equals(locomotionState, n"crouchSprint") || Equals(locomotionState, n"coolExitJump") || stateContext.IsStateActive(n"Locomotion", n"sprint") || StatusEffectSystem.ObjectHasStatusEffectWithTag(scriptInterface.executionOwner, n"JustDodged") || StatusEffectSystem.ObjectHasStatusEffect(scriptInterface.executionOwner, t"BaseStatusEffect.DriverCombatVehicleManeuvers") {
        StatusEffectHelper.ApplyStatusEffect(scriptInterface.executionOwner, t"BaseStatusEffect.ForceCritOnNextThrowSE");
      };
    };
    // stateContext.SetTemporaryBoolParameter(n"requestKerenzikovDeactivationWithEaseOut", true, true);
    scriptInterface.GetTargetingSystem().SetPlayerAimWeaponPositionProvider(scriptInterface.executionOwner, IPositionProvider.CreateSlotPositionProvider(scriptInterface.executionOwner, n"RightHand"));
  }