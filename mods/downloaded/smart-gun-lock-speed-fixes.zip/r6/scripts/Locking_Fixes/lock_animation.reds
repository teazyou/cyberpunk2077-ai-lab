// locking crosshair
@replaceMethod(Crosshair_Smart_Rifl_Bucket)
private final func StartLocking(const data: script_ref<smartGunUITargetParameters>, params: ref<smartGunUIParameters>, playerPuppet: ref<GameObject>, scheduleSFX: Bool) -> Void {
    let delayedSoundClue: ref<DelayedSmartGunUISoundClue>;
    let i: Int32;
    let playbackOptions: inkAnimOptions;
    //
    // FTLog("m_lockingAnimationLength " + ToString(this.m_lockingAnimationLength));

    // FTLog("params.timeToLock 1 " + ToString(params.timeToLock));
    // apply the stat
    let statsObjectID = Cast<StatsObjectID>(data.entityID);
    let speed = GameInstance.GetStatsSystem(GetGameInstance()).GetStatValue(statsObjectID, gamedataStatType.SmartGunTimeToLockChestComponentMultiplier);
    // FTLog("speed " + ToString(speed));
    params.timeToLock = params.timeToLock * speed;
    // FTLog("params.timeToLock 2 " + ToString(params.timeToLock));

    // logic changes here, for some reason it intentionally does not work under 0.3
    let customTimeDilation: Float = this.m_lockingAnimationLength / params.timeToLock;
    // FTLog("customTimeDilation 1 " + ToString(customTimeDilation));
    customTimeDilation *= 0.74;
    // FTLog("customTimeDilation 2 " + ToString(customTimeDilation));
    //
    playbackOptions.applyCustomTimeDilation = true;
    playbackOptions.customTimeDilation = customTimeDilation;
    this.m_lockingAnimationProxy = this.PlayLibraryAnimation(n"locking", playbackOptions);
    if scheduleSFX {
        ArrayClear(this.m_activeCallbacks);
        i = 0;
        while i < ArraySize(params.smartAudioEvents) {
        delayedSoundClue = DelayedSmartGunUISoundClue.Create(playerPuppet, params.smartAudioEvents[i]);
        ArrayPush(this.m_activeCallbacks, GameInstance.GetDelaySystem(playerPuppet.GetGame()).DelayCallback(delayedSoundClue, params.smartAudioEventsDelays[i] * params.timeToLock, true));
        i += 1;
        };
    };
}

// piggyback off the exp gain for grenade gadget
@wrapMethod(EffectExecutor_GivePlayerReward)
public final func Process(ctx: EffectScriptContext, applierCtx: EffectExecutionScriptContext) -> Bool {
    let player: ref<PlayerPuppet> = EffectScriptContext.GetInstigator(ctx) as PlayerPuppet;
    let targetNPC: ref<NPCPuppet> = EffectExecutionScriptContext.GetTarget(applierCtx) as NPCPuppet;
    let instigator: ref<Entity> = EffectScriptContext.GetInstigator(ctx);
    let target: ref<Entity> = EffectExecutionScriptContext.GetTarget(applierCtx);
    if IsDefined(player) && IsDefined(targetNPC) && instigator != target {
        if EffectScriptContext.GetSource(ctx).IsA(n"BaseGrenade") {
            let baseGrenade = EffectScriptContext.GetSource(ctx) as BaseGrenade;
            // FTLog("baseGrenade " + ToString(baseGrenade));
            if Equals(baseGrenade.GetGrenadeType(), EGrenadeType.Recon) {      
                // FTLog("itemid " + TDBID.ToStringDEBUG(ItemID.GetTDBID(baseGrenade.GetItemID())));
                let attackRecord = TweakDBInterface.GetAttackRecord(TweakDBInterface.GetForeignKeyDefault(ItemID.GetTDBID(baseGrenade.GetItemID()) + t".additionalAttack"));
                let statusEffects: array<wref<StatusEffectAttackData_Record>>;
                attackRecord.StatusEffects(statusEffects);
                let statusEffect = statusEffects[0].StatusEffect().GetID();
                // FTLog("s " + TDBID.ToStringDEBUG(statusEffect));
                StatusEffectHelper.ApplyStatusEffect(targetNPC, statusEffect, player.GetEntityID());
            }
        }
    }

    return wrappedMethod(ctx, applierCtx);
}



// debugging
// @wrapMethod(NPCPuppet)
// protected cb func OnStatusEffectApplied(evt: ref<ApplyStatusEffectEvent>) -> Bool {
// 	if (evt.staticData.GetID() != t"BaseStatusEffect.StaminaRatioCalculator"){
// 		FTLog("OnStatusEffectApplied: " + (TDBID.ToStringDEBUG(evt.staticData.GetID())));
//         // FTLog("proxyEntityID " + ToString(GameInstance.FindEntityByID(GetGameInstance(), evt.proxyEntityID)));
// 	}
// 	wrappedMethod(evt);

// }



// new attack when a recon grenade goes off since the old one doesn't apply status effects
// failed, does not reach through walls
// @wrapMethod(BaseGrenade)
// protected func Detonate(opt hitNormal: Vector4) -> Void {
//     wrappedMethod(hitNormal);
//     if this.IsGrenadeOfType(EGrenadeType.Recon) {
//         let attackRadius = this.GetAttackRadius();
//         let attackDuration = this.GetAttackDuration();
//         let attackTweak = this.m_tweakRecord.AdditionalAttack().GetID();
//         let attackRecord = TweakDBInterface.GetAttackRecord(attackTweak + t"_Fixed");
//         let additionalEffect = this.SpawnAttack(attackRecord, attackRadius, attackDuration, hitNormal);
//         additionalEffect.AttachToEntity(this, GetAllBlackboardDefs().EffectSharedData.position);
//         // FTLog("attackRecord " + TDBID.ToStringDEBUG(attackRecord.GetID()));

//         // let fakepuppet: PlayerPuppet = this as PlayerPuppet;
//         // let list = this.GetNPCsAroundObject(attackRadius);
//         // FTLog("len " + ToString(ArraySize(list)));
//     }

// }