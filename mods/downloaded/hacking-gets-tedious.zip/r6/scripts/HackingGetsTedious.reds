@replaceMethod(MinigameGenerationRuleOverridePrograms)
protected func OnProcessRule(size: Uint32, out grid: array<array<GridCell>>) -> Bool {
  let program: UnlockableProgram;
  let overrideProgramList: array<wref<Program_Record>>;
  let programRecord: ref<Program_Record>;
  let minigameRecord: ref<MinigameAction_Record>;
  let i: Int32;
  let j: Int32;
  let obj: ref<ObjectAction_Record>;
  let programChain: array<Int32>;
  let programChainRecord: Int32;
  let finalChain: array<Uint32>;
  let rand: Float;
  this.m_minigameRecord.OverrideProgramsList(overrideProgramList);
  for programRecord in overrideProgramList {
    obj = programRecord.Program();
    program.programTweakID = obj.GetID();
    minigameRecord = TweakDBInterface.GetMinigameActionRecord(program.programTweakID);
    program.name = StringToName(LocKeyToString(minigameRecord.ObjectActionUI().Caption()));
    program.note = minigameRecord.ObjectActionUI().Description();
    program.iconTweakID = minigameRecord.ObjectActionUI().CaptionIcon().TexturePartID().GetID();
    program.isFulfilled = true;
    programChain = programRecord.CharactersChain();
    for programChainRecord in programChain {
      if (programChainRecord == -1) {
        rand = RandRangeF(0.0, 1.0);
        ArrayPush(finalChain, Cast<Uint32>(this.minigameController.GetRarity(rand)));
      } else {
        ArrayPush(finalChain, Cast<Uint32>(programChainRecord));
      }
    }
    this.minigameController.AddUnlockableProgram(program, finalChain);
    ArrayClear(finalChain);
  }
  return true;
}

@replaceMethod(MinigameGenerationRuleScalingPrograms)
protected func OnProcessRule(size: Uint32, out grid: array<array<GridCell>>) -> Bool {
  let powerLevel: Float;
  let programComplexity: Float;
  let combinedPowerLevel: Float;
  let length: Int32;
  let i: Int32;
  let x: Int32;
  let playerPrograms: array<MinigameProgramData>;
  let playerProgramRecord: array<MinigameProgramData>;
  let program: UnlockableProgram;
  let rand: Float;
  let overlapProbability: Float;
  let atStart: Bool;
  let overlappingPrograms: array<Overlap>;
  let overlapInstance: Overlap;
  let miniGameRecord: wref<Minigame_Def_Record>;
  let miniGameActionRecord: wref<MinigameAction_Record>;
  let tempPrograms: array<TweakDBID>;
  let extraDifficulty: Float;
  this.m_bbNetwork = this.m_blackboardSystem.Get(GetAllBlackboardDefs().NetworkBlackboard);
  this.m_isOfficerBreach = this.m_bbNetwork.GetBool(GetAllBlackboardDefs().NetworkBlackboard.OfficerBreach);
  this.m_isRemoteBreach = this.m_bbNetwork.GetBool(GetAllBlackboardDefs().NetworkBlackboard.RemoteBreach);
  this.m_isFirstAttempt = this.m_bbNetwork.GetInt(GetAllBlackboardDefs().NetworkBlackboard.Attempt) == 1;
  playerPrograms = this.minigameController.GetPlayerPrograms();
  this.FilterPlayerPrograms(playerPrograms);
  miniGameRecord = TweakDBInterface.GetMinigame_DefRecord(t"minigame_v2.DefaultMinigame");
  powerLevel = GameInstance.GetStatsSystem((this.m_entity as GameObject).GetGame()).GetStatValue(Cast<StatsObjectID>(this.m_entity.GetEntityID()), gamedataStatType.PowerLevel);
  extraDifficulty = miniGameRecord.ExtraDifficulty();
  overlapProbability = miniGameRecord.OverlapProbability();
  this.RandomMode(atStart);
  if (ArraySize(playerPrograms) > 0) {
    i = 0;
    while i < ArraySize(playerPrograms) + 1 {
      rand = RandRangeF(0.0, 1.0);
      if (rand < overlapProbability) {
        overlapInstance.instructionNumber = i;
        x = RandDifferent(i, ArraySize(playerPrograms) + 1);
        rand = RandRangeF(0.0, 1.0);
        overlapInstance.otherInstruction = x;
        overlapInstance.atStart = atStart;
        overlapInstance.rarity = this.minigameController.GetRarity(rand);
        ArrayPush(overlappingPrograms, overlapInstance);
        this.RandomMode(atStart);
      }
      i += 1;
    }
  }
  ArrayClear(tempPrograms);
  for playerProgramRecord in playerPrograms {
    miniGameActionRecord = TweakDBInterface.GetMinigameActionRecord(playerProgramRecord.actionID);
    programComplexity = miniGameActionRecord.Complexity();
    combinedPowerLevel = (programComplexity + powerLevel) + extraDifficulty;
    length = this.DefineLength(combinedPowerLevel, this.m_bufferSize, ArraySize(playerPrograms));
    program.name = StringToName(LocKeyToString(miniGameActionRecord.ObjectActionUI().Caption()));
    program.note = miniGameActionRecord.ObjectActionUI().Description();
    program.programTweakID = playerProgramRecord.actionID;
    program.iconTweakID = miniGameActionRecord.ObjectActionUI().CaptionIcon().TexturePartID().GetID();
    program.isFulfilled = true;
    if (!ArrayContains(tempPrograms, program.programTweakID)) {
      ArrayPush(tempPrograms, program.programTweakID);
      this.minigameController.AddUnlockableProgram(program, this.GenerateRarities(length, overlappingPrograms, i + 1));
    }
  }
  return true;
}