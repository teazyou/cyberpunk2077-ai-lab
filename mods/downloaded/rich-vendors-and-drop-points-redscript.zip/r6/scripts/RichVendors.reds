@replaceMethod(Vendor)
  private final func PerformItemTransfer(buyer: wref<GameObject>, seller: wref<GameObject>, const itemTransaction: script_ref<SItemTransaction>) -> Bool {
    let moneyStack: SItemStack;
    let blackBoard: ref<IBlackboard>;
    let buyerHasEnoughMoney: Bool;
    let buyerMoney: Int32;
    let sellerHasEnoughItems: Bool;
    let sellerItemQuantity: Int32;
    let totalPrice: Int32;
    let transactionSystem: ref<TransactionSystem>;
    let uiSystem: ref<UISystem>;
    let vendorNotification: ref<UIMenuNotificationEvent>;
    this.FillVendorInventory(false);
    this.m_lastInteractionTime = GameInstance.GetTimeSystem(this.m_gameInstance).GetGameTimeStamp();
    blackBoard = GameInstance.GetBlackboardSystem(buyer.GetGame()).Get(GetAllBlackboardDefs().UI_Vendor);
    transactionSystem = GameInstance.GetTransactionSystem(this.m_gameInstance);
    totalPrice = Deref(itemTransaction).pricePerItem * Deref(itemTransaction).itemStack.quantity;
    buyerMoney = transactionSystem.GetItemQuantity(buyer, MarketSystem.Money());
    sellerItemQuantity = transactionSystem.GetItemQuantity(seller, Deref(itemTransaction).itemStack.itemID);
    buyerHasEnoughMoney = buyerMoney >= totalPrice;
    sellerHasEnoughItems = sellerItemQuantity >= Deref(itemTransaction).itemStack.quantity;
    if sellerItemQuantity == 0 {
      return false;
    };
    if !buyerHasEnoughMoney {
      vendorNotification = new UIMenuNotificationEvent();
      if buyer.IsPlayer() {
        vendorNotification.m_notificationType = UIMenuNotificationType.VNotEnoughMoney;
      } else {
        moneyStack.itemID = MarketSystem.Money();
        moneyStack.quantity = 500000;
        transactionSystem.GiveItem(buyer, moneyStack.itemID, moneyStack.quantity);
      };
      uiSystem = GameInstance.GetUISystem(this.m_gameInstance);
      uiSystem.QueueEvent(vendorNotification);
      return false;
    };
    GameInstance.GetTelemetrySystem(buyer.GetGame()).LogItemTransaction(buyer, seller, Deref(itemTransaction).itemStack.itemID, Cast<Uint32>(Deref(itemTransaction).pricePerItem), Cast<Uint32>(Deref(itemTransaction).itemStack.quantity), Cast<Uint32>(totalPrice));
    if !sellerHasEnoughItems {
      transactionSystem.GiveItem(seller, Deref(itemTransaction).itemStack.itemID, Deref(itemTransaction).itemStack.quantity - sellerItemQuantity);
    };
    transactionSystem.TransferItem(seller, buyer, Deref(itemTransaction).itemStack.itemID, Deref(itemTransaction).itemStack.quantity, Deref(itemTransaction).itemStack.dynamicTags);
    transactionSystem.TransferItem(buyer, seller, MarketSystem.Money(), totalPrice);
    blackBoard.SignalVariant(GetAllBlackboardDefs().UI_Vendor.VendorData);
    return true;
  }