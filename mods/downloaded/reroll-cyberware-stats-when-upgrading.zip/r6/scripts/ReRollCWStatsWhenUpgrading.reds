// Copyright (c) 2024 v1ld.git@gmail.com. All Rights Reserved.
//
// Feel free to reuse under the MIT License.

native func LogChannel(channel: CName, const text: script_ref<String>)

@wrapMethod(RipperDocGameController)
  private final func StartCWUpgrade() -> Void {
    wrappedMethod();
    // Increment the seed depending on how many choices were shown to the player,
    // bearing in mind the first choice is always an upgrade to the current stats 
    let seedIncrement: Uint32 = IsDefined(this.m_upgradeData.option3InventoryItem) ? 2u : 1u;
    GameInstance.GetInventoryManager(this.m_player.GetGame()).IncrementCyberwareUpgradeSeed(seedIncrement);
  }