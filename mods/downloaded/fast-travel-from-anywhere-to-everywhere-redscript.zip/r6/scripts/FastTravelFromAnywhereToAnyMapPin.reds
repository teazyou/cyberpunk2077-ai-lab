module FastTravelFromAnywhereToAnyMapPin

@replaceMethod(WorldMapMenuGameController)
  private final func FastTravel() -> Void {
    let mappin: ref<FastTravelMappin>;
    let nextLoadingTypeEvt: ref<inkSetNextLoadingScreenEvent>;
    let player: ref<GameObject>;
    let request: ref<PerformFastTravelRequest>;
    let evt: ref<inkMenuLayer_SetCursorType>;
    mappin = this.selectedMappin.GetMappin() as FastTravelMappin; 
    player = GameInstance.GetPlayerSystem(this.GetOwner().GetGame()).GetLocalPlayerMainGameObject();
    if player == null {
      return;
    };
    this.m_menuEventDispatcher.SpawnEvent(n"OnBack");
    GameInstance.GetTimeSystem(this.m_player.GetGame()).UnsetTimeDilation(n"WorldMap");
    GameInstance.GetGodModeSystem(this.m_player.GetGame()).RemoveGodMode(this.m_player.GetEntityID(), gameGodModeType.Invulnerable, n"WorldMap");
    this.m_mapBlackboard.SetString(this.m_mapDefinition.currentState, "Uninitialized");
    this.UninitializeCustomFiltersList();
    inkWidgetRef.UnregisterFromCallback(this.m_preloaderWidget, n"OnFinished", this, n"OnRemovePreloader");
    this.m_audioSystem.Play(n"ui_menu_scrolling_stop");
    if this.m_startedFastTraveling {
      this.m_audioSystem.Play(n"ui_menu_item_crafting_fail");
    };
    evt = new inkMenuLayer_SetCursorType();
    evt.Init(n"default");
    this.QueueEvent(evt);
    this.m_menuEventDispatcher.SpawnEvent(n"OnBack");
    player = GameInstance.GetPlayerSystem(this.GetOwner().GetGame()).GetLocalPlayerMainGameObject();
    GameInstance.GetTeleportationFacility(this.GetOwner().GetGame()).Teleport(player, this.selectedMappin.GetMappin().GetWorldPosition(), Vector4.ToRotation(player.GetWorldForward()));
    this.m_menuEventDispatcher.SpawnEvent(n"OnCloseHubMenu");
    nextLoadingTypeEvt = new inkSetNextLoadingScreenEvent();
    nextLoadingTypeEvt.SetNextLoadingScreenType(inkLoadingScreenType.FastTravel);
    this.QueueBroadcastEvent(nextLoadingTypeEvt);
    this.m_menuEventDispatcher.SpawnEvent(n"OnBack");
  }

@replaceMethod(WorldMapMenuGameController)
  private final func TryFastTravel() -> Void {
   if this.HasSelectedMappin() {
      this.FastTravel();
      this.m_audioSystem.Play(n"ui_menu_item_crafting_done");
      this.PlayRumble(RumbleStrength.SuperLight, RumbleType.Slow, RumblePosition.Right);
    };
  }

@replaceMethod(WorldMapMenuGameController)
  private final func UpdateTooltip(tooltipType: WorldMapTooltipType, controller: wref<BaseWorldMapMappinController>) -> Void {
    let toolTipData: WorldMapTooltipData;
    let transactionSystem: ref<TransactionSystem>;
    if controller != null {
      toolTipData.controller = controller;
      toolTipData.mappin = controller.GetMappin();
      toolTipData.journalEntry = this.GetMappinJournalEntry(toolTipData.mappin);
      toolTipData.readJournal = this.CanOpenJournalForMappin(toolTipData.mappin);
      toolTipData.moreInfo = this.CanOpenCodexPopup(toolTipData.mappin);
      toolTipData.isCollection = controller.IsCollection();
    };
    toolTipData.fastTravelEnabled = true;
    if this.IsDelamainTaxiEnabled() {
      toolTipData.delamainTaxiEnabled = true;
      toolTipData.travelCost = this.GetTravelCost();
      transactionSystem = GameInstance.GetTransactionSystem(this.m_player.GetGame());
      toolTipData.playerMoney = transactionSystem.GetItemQuantity(this.m_player, MarketSystem.Money());
    };
    this.m_tooltipController.SetData(tooltipType, toolTipData, this);
  }

@wrapMethod(WorldMapTooltipController)
public func SetData(const data: script_ref<WorldMapTooltipData>, menu: ref<WorldMapMenuGameController>) -> Void {
    wrappedMethod(data, menu);
    inkWidgetRef.SetVisible(this.m_inputInteractContainer, Deref(data).fastTravelEnabled);
}