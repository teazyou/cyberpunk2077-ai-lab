
@wrapMethod(FullscreenVendorGameController)
	private final func HandleVendorSlotClick(evt: ref<ItemDisplayClickEvent>) -> Void {
		
		let isConsumable: Bool = false;
		for i in [8, 11, 12] {
			if Equals(evt.uiInventoryItem.GetItemType(), i) {
				isConsumable = true;
			};
		};
		
		wrappedMethod(evt);
		if evt.actionName.IsAction(n"disassemble_item") && IsDefined(evt.uiInventoryItem) && isConsumable {
			if Equals(evt.displayContextData.GetDisplayContext(), ItemDisplayContext.VendorPlayer) {
				ItemActionsHelper.PerformItemAction(this.m_player, evt.uiInventoryItem.GetID());
				this.PlaySound(n"Item", n"OnBuy");
				this.Update();
			};
		};
	}

@wrapMethod(FullscreenVendorGameController)
	protected cb func OnInventoryItemHoverOver(evt: ref<ItemDisplayHoverOverEvent>) -> Bool {
		
		let isConsumable: Bool = false;
		for i in [8, 11, 12] {
			if Equals(evt.uiInventoryItem.GetItemType(), i) {
				isConsumable = true;
			};
		};
		
		let controller: ref<DropdownListController> = inkWidgetRef.GetController(this.m_sortingDropdown) as DropdownListController;
		if !controller.IsOpened() {
			if IsDefined(this.m_vendorUserData) && Equals(evt.displayContextData.GetDisplayContext(), ItemDisplayContext.VendorPlayer) && evt.uiInventoryItem != null && isConsumable {
				this.m_buttonHintsController.AddButtonHint(n"disassemble_item", GetLocalizedText("LocKey#6891"));
			};
		};

		wrappedMethod(evt);
	}

@wrapMethod(FullscreenVendorGameController)
	protected cb func OnInventoryItemHoverOut(evt: ref<ItemDisplayHoverOutEvent>) -> Bool {
		wrappedMethod(evt);
		this.m_buttonHintsController.RemoveButtonHint(n"disassemble_item");
	}
