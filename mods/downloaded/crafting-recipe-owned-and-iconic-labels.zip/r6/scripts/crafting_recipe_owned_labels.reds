@addMethod(CraftingLogicController) public static func DisplayOwnedOnAmmo() -> Bool = true
@addMethod(CraftingLogicController) public static func DisplayOwnedOnCraftingMaterials() -> Bool = true
// would only show if *crafted* weapons are owned
@addMethod(CraftingLogicController) public static func DisplayOwnedOnWeapons() -> Bool = true

@addField(RecipeData)
public let owned: Bool;
@addField(RecipeData)
public let isIconic: Bool;
@addField(RecipeData)
public let isAmmoAtMax: Bool;

@addField(InventoryItemDisplayController)
public let isIconic: Bool;

@wrapMethod(CraftingLogicController)
private final func GetRecipesList() -> array<ref<IScriptable>> {
  let recipes: array<ref<IScriptable>> = wrappedMethod();

  let equippedQuickhacks: array<TweakDBID> = PlayerPuppet.GetPlayerQuickHackInCyberDeckTweakDBID(this.m_Player);

  let i: Int32 = 0;
  while i < ArraySize(recipes) {
    let recipe: ref<RecipeData> = recipes[i] as RecipeData;
    
    let outList: array<wref<StatModifier_Record>>;
    recipe.id.StatModifiers(outList);
    for statModifier in outList {
      if statModifier.GetID() == t"Quality.IconicItem" {
        recipe.isIconic = true;
        break;
      }
    }

    if IsDefined(recipe) {
      if Equals(recipe.inventoryItem.ItemType, gamedataItemType.Con_Ammo) {
        if CraftingLogicController.DisplayOwnedOnAmmo() {
          if RPGManager.HasItem(this.m_Player, recipe.id.GetID()) {
            recipe.owned = true;
          }
          recipe.isAmmoAtMax = this.m_craftingSystem.GetMaxCraftingAmount(InventoryItemData.GetGameItemData(recipe.inventoryItem)) == 0;
        }
      }
      else if InventoryItemData.IsWeapon(recipe.inventoryItem) {
        // would need to map craftable weapons to non-craftable versions for this to show on all weapons
        if CraftingLogicController.DisplayOwnedOnWeapons() {
          if RPGManager.HasItem(this.m_Player, recipe.id.GetID()) {
            recipe.owned = true;
          }
        }
      }
      else if recipe.id.GetID() == t"Items.CommonMaterial1" || recipe.id.GetID() == t"Items.UncommonMaterial1" || recipe.id.GetID() == t"Items.RareMaterial1" || recipe.id.GetID() == t"Items.EpicMaterial1" || recipe.id.GetID() == t"Items.LegendaryMaterial1" {
        if CraftingLogicController.DisplayOwnedOnCraftingMaterials() {
          if RPGManager.HasItem(this.m_Player, recipe.id.GetID()) {
            recipe.owned = true;
          }
        }
      }
      // rest of items are mods and quickhacks
      else if RPGManager.HasItem(this.m_Player, recipe.id.GetID()) {
        recipe.owned = true;
      }
      // equipped quickhacks are not in the inventory
      else {
        for hack in equippedQuickhacks {
          if hack == recipe.id.GetID() {
            recipe.owned = true;
            break;
          }
        }
      }
    }
    i += 1;
  }

  return recipes;
}

@replaceMethod(CraftableItemLogicController)
private final func UpdateControllerData() -> Void {
  if IsDefined(this.m_itemData) {
    // adding skipped optionals here (false, false)
    this.m_controller.Setup(this.m_itemData.inventoryItem, ItemDisplayContext.Crafting, false, false, this.m_itemData.isUpgradable);
    this.SelectSlot(this.m_itemData.isSelected);
  };
  if IsDefined(this.m_recipeData) {
    // change here to add owned
    this.m_controller.Setup(this.m_recipeData, ItemDisplayContext.Crafting, this.m_recipeData.owned, this.m_recipeData.isIconic, this.m_recipeData.isAmmoAtMax);
    this.m_controller.SetIsNew(this.m_recipeData.isNew);
    this.SelectSlot(this.m_recipeData.isSelected);
  };
  inkWidgetRef.SetVisible(this.m_normalAppearence, true);
}

@addMethod(InventoryItemDisplayController)
public func Setup(recipeData: ref<RecipeData>, opt displayContext: ItemDisplayContext, opt owned: Bool, opt isIconic: Bool, opt isAmmoAtMax: Bool) -> Void {
  this.SetDisplayContext(displayContext, recipeData);
  this.m_isUpgradable = this.m_recipeData.isCraftable;
  this.m_owned = owned;
  this.isIconic = isIconic;
  if isAmmoAtMax {
    this.m_isUpgradable = false;
  }
  this.RefreshUI();
}

@wrapMethod(InventoryItemDisplayController)
protected func NewUpdateIndicators(itemData: ref<UIInventoryItem>) -> Void {
  wrappedMethod(itemData);
  
  if IsDefined(this.m_labelsContainerController) {
    if Equals(this.m_displayContextData.GetDisplayContext(), ItemDisplayContext.Crafting) {
      if this.m_owned {
        this.m_labelsContainerController.Add(ItemLabelType.Owned);
      }
      inkWidgetRef.SetVisible(this.m_iconicTint, this.isIconic);
    }
  }
}

@wrapMethod(InventoryItemDisplayController)
protected func UpdateIndicators() -> Void {
  wrappedMethod();
  
  if Equals(this.m_itemDisplayContext, ItemDisplayContext.Crafting) {
    if IsDefined(this.m_labelsContainerController) {
      if this.m_owned {
        this.m_labelsContainerController.Add(ItemLabelType.Owned);
      }
      inkWidgetRef.SetVisible(this.m_iconicTint, this.isIconic);
    }
  }
}


// BUG FIX for when pressing left mouse or equivalent controller button outside of the crafting button or item icon.

@addMethod(CraftingMainLogicController)
protected func SetProgressButtonProgressBarVisibility(visible: Bool) -> Void {
  let bar = inkCompoundRef.GetWidget(this.m_progressButtonContainer, n"textPanel/FastTravelInputDisplayController/HoldHolder/root");
  if IsDefined(bar) {
    bar.SetVisible(visible && this.m_isCraftable);
  }
}

@wrapMethod(CraftingMainLogicController)
protected final func SetCraftingButton(const label: script_ref<String>) -> Void {
  wrappedMethod(label);

  this.SetProgressButtonProgressBarVisibility(false);
  this.m_progressButtonController.ButtonController.RegisterToCallback(n"OnHoverOver", this, n"ProgressButtonOnHoverOver");
  this.m_progressButtonController.ButtonController.RegisterToCallback(n"OnHoverOut", this, n"ProgressButtonOnHoverOut");
}

@wrapMethod(CraftingMainLogicController)
protected cb func OnUninitialize() -> Bool {
  wrappedMethod();

  this.m_progressButtonController.ButtonController.UnregisterFromCallback(n"OnHoverOver", this, n"SelectedItemOnHoverOver");
  this.m_progressButtonController.ButtonController.UnregisterFromCallback(n"OnHoverOut", this, n"SelectedItemOnHoverOut");
  if IsDefined(this.m_currentSelected) {
    this.m_currentSelected.UnregisterFromCallback(n"OnHoverOver", this, n"SelectedItemOnHoverOver");
    this.m_currentSelected.UnregisterFromCallback(n"OnHoverOut", this, n"SelectedItemOnHoverOut");
  }
}

@wrapMethod(CraftingMainLogicController)
private final func UpdateSelection(selection: ref<CraftableItemLogicController>) -> Void {
  wrappedMethod(selection);

  if IsDefined(this.m_currentSelected) {
    this.m_currentSelected.UnregisterFromCallback(n"OnHoverOver", this, n"SelectedItemOnHoverOver");
    this.m_currentSelected.UnregisterFromCallback(n"OnHoverOut", this, n"SelectedItemOnHoverOut");
  }

  this.SetProgressButtonProgressBarVisibility(true);
  this.m_currentSelected.RegisterToCallback(n"OnHoverOver", this, n"SelectedItemOnHoverOver");
  this.m_currentSelected.RegisterToCallback(n"OnHoverOut", this, n"SelectedItemOnHoverOut");
}

@wrapMethod(CraftingMainLogicController)
private final func OnPressSelectedItem(evt: ref<inkPointerEvent>) -> Void {
  wrappedMethod(evt);
  this.SetProgressButtonProgressBarVisibility(true);
}

@addMethod(CraftingMainLogicController)
protected func ProgressButtonOnHoverOver(evt: ref<inkPointerEvent>) -> Void {
  this.SetProgressButtonProgressBarVisibility(true);
}

@addMethod(CraftingMainLogicController)
protected func ProgressButtonOnHoverOut(evt: ref<inkPointerEvent>) -> Void {
  this.SetProgressButtonProgressBarVisibility(false);
}

@addMethod(CraftingMainLogicController)
protected func SelectedItemOnHoverOver(evt: ref<inkPointerEvent>) -> Void {
  this.SetProgressButtonProgressBarVisibility(true);
}

@addMethod(CraftingMainLogicController)
protected func SelectedItemOnHoverOut(evt: ref<inkPointerEvent>) -> Void {
  this.SetProgressButtonProgressBarVisibility(false);
}

// COUNT MONOWIRE HACK AS OWNED
@wrapMethod(PlayerPuppet)
public final static func GetPlayerQuickHackInCyberDeck(player: wref<PlayerPuppet>) -> [ItemID] {
  let hacksInDeck: array<ItemID> = wrappedMethod(player);
  let i: Int32;
  let installedPartId: TweakDBID;
  let parts: array<SPartSlots>;
  let armsID: ItemID = EquipmentSystem.GetData(player).GetActiveItem(gamedataEquipmentArea.ArmsCW);
  
  parts = ItemModificationSystem.GetAllSlots(player, armsID);
  i = 0;
  while i < ArraySize(parts) {
    if Equals(parts[i].status, ESlotState.Taken) {
      installedPartId = ItemID.GetTDBID(parts[i].installedPart);
      if installedPartId != t"Items.GenericItemRoot" {
        if !ArrayContains(hacksInDeck, parts[i].installedPart) {
          ArrayPush(hacksInDeck, parts[i].installedPart);
        }
      }
    }
    i += 1;
  }
  return hacksInDeck;
}
