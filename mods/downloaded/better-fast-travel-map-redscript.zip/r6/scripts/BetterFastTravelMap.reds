@replaceMethod(WorldMapMenuGameController)
  protected cb func OnUninitialize() -> Bool {
    let evt: ref<inkMenuLayer_SetCursorType>;
    this.SaveFilters();
    GameInstance.GetTimeSystem(this.m_player.GetGame()).UnsetTimeDilation(n"WorldMap");
    GameInstance.GetGodModeSystem(this.m_player.GetGame()).RemoveGodMode(this.m_player.GetEntityID(), gameGodModeType.Invulnerable, n"WorldMap");
    this.m_menuEventDispatcher.UnregisterFromEvent(n"OnBack", this, n"OnBack");
    this.m_mapBlackboard.SetString(this.m_mapDefinition.currentState, "Uninitialized");
    this.UninitializeCustomFiltersList();
    inkWidgetRef.UnregisterFromCallback(this.m_preloaderWidget, n"OnFinished", this, n"OnRemovePreloader");
    this.m_audioSystem.Play(n"ui_menu_scrolling_stop");
    if this.m_startedFastTraveling {
      this.m_audioSystem.Play(n"ui_menu_item_crafting_fail");
    };
    evt = new inkMenuLayer_SetCursorType();
    evt.Init(n"default");
    this.QueueEvent(evt);
    this.CancelDelamainTaxiMappinPosition();
  }

@replaceMethod(WorldMapMenuGameController)
  protected cb func OnEntityAttached() -> Bool {
    let delamainTaxiEnabled: Bool;
    let delayEvent: ref<MapNavigationDelay>;
    let fastTravelEnabled: Bool;
    let preloaderController: wref<WorldMapPreloader>;
    let mappinSpawnContainer: wref<inkCompoundWidget> = this.GetSpawnContainer();
    mappinSpawnContainer.RegisterToCallback(n"OnEnter", this, n"OnHoverOverMappin");
    mappinSpawnContainer.RegisterToCallback(n"OnLeave", this, n"OnHoverOutMappin");
    this.RegisterToGlobalInputCallback(n"OnPostOnAxis", this, n"OnAxisInput");
    this.RegisterToGlobalInputCallback(n"OnPostOnPress", this, n"OnPressInput");
    this.RegisterToGlobalInputCallback(n"OnPostOnRelease", this, n"OnReleaseInput");
    this.RegisterToGlobalInputCallback(n"OnPostOnHold", this, n"OnHoldInput");
    this.m_cameraMode = this.GetEntityPreview().GetCameraMode();
    fastTravelEnabled = this.IsFastTravelEnabled();
    this.UpdateFastTravelVisiblity(fastTravelEnabled);
    if fastTravelEnabled {

    };
    delamainTaxiEnabled = this.IsDelamainTaxiEnabled();
    this.UpdateDelamainTaxiVisiblity(delamainTaxiEnabled);
    if IsDefined(this.m_initMappinFocus) {
      delayEvent = new MapNavigationDelay();
      this.QueueEvent(delayEvent);
    };
    this.m_mapBlackboard.SetString(this.m_mapDefinition.currentState, "EntityAttached");
    preloaderController = inkWidgetRef.GetController(this.m_preloaderWidget) as WorldMapPreloader;
    preloaderController.SetMapLoaded();
    this.RefreshInputHints();
    this.m_entityAttached = true;
  }

@replaceMethod(WorldMapMenuGameController)
  private final func UpdateFastTravelVisiblity(fastTravelEnabled: Bool) -> Void {
    inkWidgetRef.SetVisible(this.m_fastTravelInstructions, false);
    inkWidgetRef.SetVisible(this.m_topShadow, !fastTravelEnabled);
    inkWidgetRef.SetVisible(this.m_openInJournalButton, !fastTravelEnabled);
  }

@replaceMethod(WorldMapMenuGameController)
  private final func TryTrackQuestOrSetWaypoint() -> Void {
    if this.IsFastTravelEnabled() {

    };
    if this.IsDelamainTaxiEnabled() {
      this.TrackDelamainTaxiMappin();
      this.UpdateTravelDestination();
      this.UpdateSelectedMappinTooltip();
    } else {
      if this.selectedMappin != null {
        if this.selectedMappin.IsDelamainTaxiTracked() {
          return;
        };
        if this.selectedMappin.IsInCollection() && this.selectedMappin.IsCollection() || !this.selectedMappin.IsInCollection() {
          if this.CanQuestTrackMappin(this.selectedMappin) {
            if !this.IsMappinQuestTracked(this.selectedMappin) {
              this.UntrackCustomPositionMappin();
              this.TrackQuestMappin(this.selectedMappin);
              this.PlaySound(n"MapPin", n"OnEnable");
              this.PlayRumble(RumbleStrength.SuperLight, RumbleType.Slow, RumblePosition.Right);
            };
          } else {
            if this.CanPlayerTrackMappin(this.selectedMappin) {
              if this.selectedMappin.IsCustomPositionTracked() {
                this.UntrackCustomPositionMappin();
                this.SetSelectedMappin(null);
                this.PlaySound(n"MapPin", n"OnDisable");
                this.PlayRumble(RumbleStrength.SuperLight, RumbleType.Pulse, RumblePosition.Right);
              } else {
                if this.selectedMappin.IsPlayerTracked() && this.selectedMappin.IsDelamainTaxiTracked() {
                  this.UntrackMappin();
                  this.PlaySound(n"MapPin", n"OnDisable");
                  this.PlayRumble(RumbleStrength.SuperLight, RumbleType.Pulse, RumblePosition.Right);
                } else {
                  this.UntrackCustomPositionMappin();
                  this.TrackMappin(this.selectedMappin);
                  this.PlaySound(n"MapPin", n"OnEnable");
                  this.PlayRumble(RumbleStrength.SuperLight, RumbleType.Slow, RumblePosition.Right);
                };
              };
            };
          };
          this.UpdateSelectedMappinTooltip();
        };
      } else {
        this.TrackCustomPositionMappin();
      };
    };
    this.PlaySound(n"MapPin", n"OnCreate");
  }
